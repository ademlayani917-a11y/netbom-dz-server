# NETBOM DZ Turso Server

هذا سيرفر حفظ الحسابات والبروفايلات والمشاهدة لـ NETBOM DZ باستخدام:
- Express
- Turso / libSQL
- JWT
- bcrypt

## التشغيل المحلي

1. انسخ `.env.example` إلى `.env`.
2. ضع القيم:

```env
PORT=5000
CLIENT_URL=https://netbomdz.top,http://localhost:8000
TURSO_DATABASE_URL=libsql://YOUR_DATABASE.turso.io
TURSO_AUTH_TOKEN=YOUR_TOKEN
JWT_SECRET=اكتب_سر_طويل_عشوائي
```

3. ثبت الحزم:

```bash
npm install
```

4. أنشئ الجداول:

```bash
npm run init-db
```

5. شغل السيرفر:

```bash
npm start
```

## الروابط المهمة

- صحة السيرفر: `GET /api/health`
- تسجيل: `POST /api/auth/register`
- دخول: `POST /api/auth/login`
- البروفايلات: `/api/profiles`
- إكمال المشاهدة: `/api/watch-history`
- قائمتي: `/api/my-list`
- الإعدادات: `/api/settings`

## مهم

لا تضع `TURSO_AUTH_TOKEN` داخل واجهة الموقع. التوكن يبقى فقط في السيرفر.
