import express from 'express';
import { db } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  let r = await db.execute({ sql: 'SELECT * FROM settings WHERE user_id = ?', args: [req.user.id] });
  if (!r.rows.length) {
    await db.execute({ sql: 'INSERT INTO settings (user_id) VALUES (?)', args: [req.user.id] });
    r = await db.execute({ sql: 'SELECT * FROM settings WHERE user_id = ?', args: [req.user.id] });
  }
  res.json({ settings: r.rows[0] });
});

router.put('/', async (req, res) => {
  const { language, accentColor, theme } = req.body || {};
  await db.execute({
    sql: `INSERT INTO settings (user_id, language, accent_color, theme) VALUES (?, COALESCE(?, 'en'), COALESCE(?, '#8b5cf6'), COALESCE(?, 'dark'))
          ON CONFLICT(user_id) DO UPDATE SET language=COALESCE(excluded.language, settings.language), accent_color=COALESCE(excluded.accent_color, settings.accent_color), theme=COALESCE(excluded.theme, settings.theme), updated_at=CURRENT_TIMESTAMP`,
    args: [req.user.id, language || null, accentColor || null, theme || null]
  });
  res.json({ ok: true });
});

export default router;
