import express from 'express';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const profileId = req.query.profileId || null;
  const args = profileId ? [req.user.id, profileId] : [req.user.id];
  const sql = profileId ? 'SELECT * FROM watch_history WHERE user_id = ? AND profile_id = ? ORDER BY updated_at DESC LIMIT 100' : 'SELECT * FROM watch_history WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100';
  const r = await db.execute({ sql, args });
  res.json({ items: r.rows });
});

router.post('/', async (req, res) => {
  const d = req.body || {};
  const id = nanoid();
  const profileId = d.profileId || null;
  const tmdbId = String(d.tmdbId || '');
  const mediaType = d.mediaType || d.type || 'movie';
  if (!tmdbId) return res.status(400).json({ error: 'tmdbId required' });
  await db.execute({
    sql: `INSERT INTO watch_history (id, user_id, profile_id, tmdb_id, media_type, title, poster, season, episode, server_id, progress, duration)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(user_id, profile_id, tmdb_id, media_type, season, episode)
          DO UPDATE SET title=excluded.title, poster=excluded.poster, server_id=excluded.server_id, progress=excluded.progress, duration=excluded.duration, updated_at=CURRENT_TIMESTAMP`,
    args: [id, req.user.id, profileId, tmdbId, mediaType, d.title || '', d.poster || '', Number(d.season || 0), Number(d.episode || 0), Number(d.serverId || d.server || 1), Number(d.progress || 0), Number(d.duration || 0)]
  });
  res.json({ ok: true });
});

router.delete('/:id', async (req, res) => {
  await db.execute({ sql: 'DELETE FROM watch_history WHERE id = ? AND user_id = ?', args: [req.params.id, req.user.id] });
  res.json({ ok: true });
});

export default router;
