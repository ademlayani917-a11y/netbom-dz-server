import express from 'express';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const profileId = req.query.profileId || null;
  const args = profileId ? [req.user.id, profileId] : [req.user.id];
  const sql = profileId ? 'SELECT * FROM my_list WHERE user_id = ? AND profile_id = ? ORDER BY created_at DESC' : 'SELECT * FROM my_list WHERE user_id = ? ORDER BY created_at DESC';
  const r = await db.execute({ sql, args });
  res.json({ items: r.rows });
});

router.post('/', async (req, res) => {
  const d = req.body || {};
  if (!d.tmdbId) return res.status(400).json({ error: 'tmdbId required' });
  await db.execute({
    sql: `INSERT OR IGNORE INTO my_list (id, user_id, profile_id, tmdb_id, media_type, title, poster) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    args: [nanoid(), req.user.id, d.profileId || null, String(d.tmdbId), d.mediaType || d.type || 'movie', d.title || '', d.poster || '']
  });
  res.json({ ok: true });
});

router.delete('/', async (req, res) => {
  const { tmdbId, mediaType, profileId } = req.body || {};
  await db.execute({ sql: 'DELETE FROM my_list WHERE user_id = ? AND profile_id IS ? AND tmdb_id = ? AND media_type = ?', args: [req.user.id, profileId || null, String(tmdbId), mediaType || 'movie'] });
  res.json({ ok: true });
});

export default router;
