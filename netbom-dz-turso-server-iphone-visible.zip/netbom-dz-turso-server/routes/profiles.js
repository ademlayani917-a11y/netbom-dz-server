import express from 'express';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const r = await db.execute({ sql: 'SELECT * FROM profiles WHERE user_id = ? ORDER BY created_at ASC', args: [req.user.id] });
  res.json({ profiles: r.rows });
});

router.post('/', async (req, res) => {
  const id = nanoid();
  const name = String(req.body.name || 'Profile').slice(0, 40);
  const avatar = req.body.avatar || '';
  const isKids = req.body.isKids ? 1 : 0;
  await db.execute({ sql: 'INSERT INTO profiles (id, user_id, name, avatar, is_kids) VALUES (?, ?, ?, ?, ?)', args: [id, req.user.id, name, avatar, isKids] });
  res.status(201).json({ profile: { id, user_id: req.user.id, name, avatar, is_kids: isKids } });
});

router.put('/:id', async (req, res) => {
  const name = req.body.name;
  const avatar = req.body.avatar;
  const isKids = req.body.isKids === undefined ? undefined : (req.body.isKids ? 1 : 0);
  const current = await db.execute({ sql: 'SELECT * FROM profiles WHERE id = ? AND user_id = ?', args: [req.params.id, req.user.id] });
  if (!current.rows.length) return res.status(404).json({ error: 'Profile not found' });
  await db.execute({ sql: `UPDATE profiles SET name = COALESCE(?, name), avatar = COALESCE(?, avatar), is_kids = COALESCE(?, is_kids), updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?`, args: [name ?? null, avatar ?? null, isKids ?? null, req.params.id, req.user.id] });
  res.json({ ok: true });
});

router.delete('/:id', async (req, res) => {
  await db.execute({ sql: 'DELETE FROM profiles WHERE id = ? AND user_id = ?', args: [req.params.id, req.user.id] });
  res.json({ ok: true });
});

export default router;
