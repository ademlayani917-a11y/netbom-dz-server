import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { nanoid } from 'nanoid';
import { db } from '../db.js';

const router = express.Router();
const sign = (user) => jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '30d' });

router.post('/register', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!email || !password || password.length < 6) return res.status(400).json({ error: 'Email and password min 6 chars required' });
  const exists = await db.execute({ sql: 'SELECT id FROM users WHERE email = ?', args: [email] });
  if (exists.rows.length) return res.status(409).json({ error: 'Email already exists' });
  const id = nanoid();
  const passwordHash = await bcrypt.hash(password, 10);
  await db.execute({ sql: 'INSERT INTO users (id, email, password_hash) VALUES (?, ?, ?)', args: [id, email, passwordHash] });
  await db.execute({ sql: 'INSERT INTO settings (user_id) VALUES (?)', args: [id] });
  const user = { id, email };
  res.status(201).json({ user, token: sign(user) });
});

router.post('/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const result = await db.execute({ sql: 'SELECT id, email, password_hash FROM users WHERE email = ?', args: [email] });
  const user = result.rows[0];
  if (!user) return res.status(401).json({ error: 'Invalid email or password' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid email or password' });
  const safeUser = { id: user.id, email: user.email };
  res.json({ user: safeUser, token: sign(safeUser) });
});

router.get('/me', async (req, res) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const user = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ user });
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
});

export default router;
