import 'dotenv/config';
import { db } from './db.js';

const statements = [
`CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`,
`CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  avatar TEXT,
  is_kids INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)`,
`CREATE TABLE IF NOT EXISTS watch_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  profile_id TEXT,
  tmdb_id TEXT NOT NULL,
  media_type TEXT NOT NULL,
  title TEXT,
  poster TEXT,
  season INTEGER DEFAULT 0,
  episode INTEGER DEFAULT 0,
  server_id INTEGER DEFAULT 1,
  progress INTEGER DEFAULT 0,
  duration INTEGER DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, profile_id, tmdb_id, media_type, season, episode),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)`,
`CREATE TABLE IF NOT EXISTS my_list (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  profile_id TEXT,
  tmdb_id TEXT NOT NULL,
  media_type TEXT NOT NULL,
  title TEXT,
  poster TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, profile_id, tmdb_id, media_type),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)`,
`CREATE TABLE IF NOT EXISTS settings (
  user_id TEXT PRIMARY KEY,
  language TEXT DEFAULT 'en',
  accent_color TEXT DEFAULT '#8b5cf6',
  theme TEXT DEFAULT 'dark',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)`,
`CREATE INDEX IF NOT EXISTS idx_profiles_user ON profiles(user_id)`,
`CREATE INDEX IF NOT EXISTS idx_watch_user_profile ON watch_history(user_id, profile_id)`,
`CREATE INDEX IF NOT EXISTS idx_mylist_user_profile ON my_list(user_id, profile_id)`
];

for (const sql of statements) await db.execute(sql);
console.log('NETBOM DZ Turso database initialized successfully.');
