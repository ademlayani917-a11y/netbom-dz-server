import 'dotenv/config';
import { createClient } from '@libsql/client';

if (!process.env.TURSO_DATABASE_URL || !process.env.TURSO_AUTH_TOKEN) {
  console.warn('Missing TURSO_DATABASE_URL or TURSO_AUTH_TOKEN in .env');
}

export const db = createClient({
  url: process.env.TURSO_DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN
});

export async function run(sql, args = []) {
  return db.execute({ sql, args });
}
